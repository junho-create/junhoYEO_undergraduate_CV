import tkinter as tk
from tkinter import ttk, messagebox
import pymysql
from datetime import datetime, timedelta

# DB 연결 정보 설정
conn = pymysql.connect(
    host='localhost',
    user='root',
    password='your_password', #mySQL 비밀번호 입력
    db='ldms',
    charset='utf8',
    autocommit=True
)
cursor = conn.cursor()

# (1)번 메뉴: 환자 입력 후 헌혈자 조회
def insert_patient_and_get_donors(name, blood_type, rh_factor, due_date, email):
    try:
        admitted_date = datetime.now().date()
        cursor.execute("INSERT INTO Patients(name, blood_type, rh_factor, due_date, email, admitted_date) VALUES(%s, %s, %s, %s, %s, %s)",
                       (name, blood_type, rh_factor, due_date, email, admitted_date))
        conn.commit()
        patient_id = cursor.lastrowid
        print(f"Patient inserted with ID: {patient_id}")  

        cursor.callproc('get_matched_donors_for_patient', (patient_id,))
        donors = cursor.fetchall()
        return patient_id, donors
    
    except pymysql.MySQLError as e:
        print(f"Database Error: {e}") 
        messagebox.showerror("Database Error", f"An error occurred: {str(e)}")
        return None, []

def show_insert_patient_window():
    win = tk.Toplevel(root)
    win.title("Insert Patient & Get Donors")

    # 라벨 및 입력 필드 추가
    
    blood_option = ["A", "B", "O", "AB"]
    rh_option = ['+', '-']

    tk.Label(win, text="Name").grid(row=0, column=0, padx=5, pady=5)
    tk.Label(win, text="Blood Type").grid(row=1, column=0, padx=5, pady=5)
    tk.Label(win, text="Rh Factor").grid(row=2, column=0, padx=5, pady=5)
    tk.Label(win, text="Due Date (YYYY-MM-DD)").grid(row=3, column=0, padx=5, pady=5)
    tk.Label(win, text="Email").grid(row=4, column=0, padx=5, pady=5)

    name_entry = tk.Entry(win)
    blood_entry = ttk.Combobox(win, values=blood_option, state="readonly")
    rh_entry = ttk.Combobox(win, values=rh_option, state="readonly")
    due_date_entry = tk.Entry(win)
    email_entry = tk.Entry(win)

    name_entry.grid(row=0, column=1, padx=5, pady=5)
    blood_entry.grid(row=1, column=1, padx=5, pady=5)
    rh_entry.grid(row=2, column=1, padx=5, pady=5)
    due_date_entry.grid(row=3, column=1, padx=5, pady=5)
    email_entry.grid(row=4, column=1, padx=5, pady=5)

    def display_donors(patient_id, donors, due_date):
        donor_frame = tk.Frame(win)
        donor_frame.grid(row=7, column=0, columnspan=2, padx=10, pady=10)

        # 우선순위별 테이블 생성
        priority_tables = {}
        for priority in range(1, 6):
            priority_tables[priority] = []

        for donor in donors:
            donor_id, name, blood_type, rh_factor, last_test_date, email, priority = donor
            last_test_date_obj = last_test_date
            due_date_obj = datetime.strptime(due_date, "%Y-%m-%d").date()

            # 상태 결정
            if last_test_date_obj + timedelta(days=14) < due_date_obj:
                status = "Re-Test Required"
            else:
                status = "Valid"

            priority_tables[priority].append((donor_id, name, blood_type, rh_factor, last_test_date, email, status))

        any_table_displayed = False
        for priority, donors in priority_tables.items():
            if donors:  # 해당 우선순위에 헌혈자가 있는 경우만 테이블 표시
                any_table_displayed = True
                frame = tk.Frame(donor_frame, borderwidth=2, relief="groove")
                frame.pack(side="top", fill="x", pady=5)

                label = tk.Label(frame, text=f"Priority {priority}", font=("Arial", 12, "bold"))
                label.pack(pady=5)

                columns = ("ID", "Name", "Blood Type", "Rh Factor", "Last Test Date", "Email", "Status")
                tree = ttk.Treeview(frame, columns=columns, show="headings", height=5, selectmode="extended")

                for col in columns:
                    tree.heading(col, text=col)
                    tree.column(col, anchor="center")

                for donor in donors:
                    donor_id, name, blood_type, rh_factor, last_test_date, email, status = donor
                    tree.insert("", "end", values=(donor_id, name, blood_type, rh_factor, last_test_date, email, status))

                tree.pack(side="top", fill="x")
                priority_tables[priority] = tree

        if not any_table_displayed:
            tk.Label(donor_frame, text="No donors found for the given criteria.", font=("Arial", 12, "italic"), fg="red").pack(pady=10)

        def send_email_to_selected():
            selected_donors = []
            for priority, tree in priority_tables.items():
                if isinstance(tree, ttk.Treeview):
                    for selected_item in tree.selection():
                        donor_data = tree.item(selected_item, "values")
                        selected_donors.append(donor_data)

            if not selected_donors:
                messagebox.showwarning("No Selection", "Please select donors to send email.")
                return

            for donor_data in selected_donors:
                email = donor_data[5]
                status = donor_data[6]
                if status == "Re-Test Required":
                    send_email(email, "Re-Test Request", "Your test validity has expired. Please retest.")
                else:
                    send_email(email, "Donation Request", "You are matched for a donation.")

        email_btn = tk.Button(donor_frame, text="Send Email to Selected Donors", command=send_email_to_selected)
        email_btn.pack(side="bottom", pady=10)

        tooltip_label = tk.Label(donor_frame, text="Click to select, Ctrl + Click to deselect donors.", font=("Arial", 8, "italic"), fg="gray")
        tooltip_label.pack(side="top", pady=5)


    def on_submit():
        name = name_entry.get()
        blood = blood_entry.get()
        rh = rh_entry.get()
        due_date = due_date_entry.get()
        email = email_entry.get()

        if not name or not blood or not rh or not due_date or not email:
            messagebox.showerror("Input Error", "All fields are required.")
            return

        # 유효한 혈액형 및 Rh Factor 검증
        '''valid_blood_types = ['A', 'B', 'AB', 'O']
        valid_rh_factors = ['+', '-']
        if blood not in valid_blood_types:
            messagebox.showerror("Input Error", f"Invalid Blood Type: {blood}. Must be one of {', '.join(valid_blood_types)}.")
            return
        if rh not in valid_rh_factors:
            messagebox.showerror("Input Error", f"Invalid Rh Factor: {rh}. Must be '+' or '-'.")
            return'''

        try:
            datetime.strptime(due_date, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Date Error", "Due date must be in YYYY-MM-DD format.")
            return
        print(name, blood, rh, due_date, email)
        p_id, donors = insert_patient_and_get_donors(name, blood, rh, due_date, email)
        tk.Label(win, text=f"Patient ID: {p_id}", font=("Arial", 10)).grid(row=6, column=0, columnspan=2, pady=10)
        display_donors(p_id, donors, due_date)

    submit_btn = tk.Button(win, text="Insert & Get Donors", command=on_submit)
    submit_btn.grid(row=5, column=0, columnspan=2, pady=10)

def send_email(to_email, subject, body):
    print(f"Sending email to {to_email} with subject '{subject}' and body '{body}'")
    messagebox.showinfo("Email Sent", f"Email sent to {to_email}")

# (2)번 메뉴: 헌혈자 입력 후 환자 조회
def insert_donor_and_get_patients(name, ssn, blood_type, rh_factor, last_test_date, email, donor_address, InputlistID):
    try:
        # 기존 헌혈자 확인
        cursor.execute("SELECT donor_id FROM Donors WHERE ssn = %s", (ssn,))
        existing_donor = cursor.fetchone()

        if existing_donor:
            # 기존 헌혈자 정보 업데이트
            cursor.execute("UPDATE Donors SET last_test_date = %s WHERE ssn = %s", (last_test_date, ssn))
            conn.commit()
            donor_id = existing_donor[0]
            messagebox.showinfo("Update Success", "Last test date has been updated.")
        else:
            # 새로운 헌혈자 삽입
            cursor.execute(
                "INSERT INTO Donors(name, ssn, blood_type, rh_factor, last_test_date, email, donor_address, InputlistID) VALUES(%s, %s, %s, %s, %s, %s, %s, %s)",
                (name, ssn, blood_type, rh_factor, last_test_date, email, donor_address, InputlistID)
            )
            conn.commit()
            donor_id = cursor.lastrowid

        # 프로시저 호출로 환자 목록 가져오기
        cursor.callproc('get_matched_patients_for_donor', (donor_id,))
        patients = cursor.fetchall()
        return donor_id, patients

    except pymysql.MySQLError as e:
        # 데이터베이스 관련 에러 처리
        print(f"Database Error: {e}")
        messagebox.showerror("Database Error", f"An error occurred: {str(e)}")
        return None, []

    except Exception as e:
        # 기타 예외 처리
        print(f"Unexpected Error: {e}")
        messagebox.showerror("Unexpected Error", f"An error occurred: {str(e)}")
        return None, []
        
def show_insert_donor_window():
    win = tk.Toplevel(root)
    win.title("Insert Donor & Get Patients")

    # Province와 City 선택지
    province_option = [
        "서울특별시", "부산광역시", "경기도", "대구광역시", "인천광역시", "광주광역시", "대전광역시", "울산광역시", 
        "세종특별자치시", "강원도", "충청북도", "충청남도", "전라북도", "전라남도", "경상북도", "경상남도", "제주도"
    ]

    # 서울시, 경기도 구/시 목록
    seoul_districts = [
        '강남구', '강동구', '강북구', '강서구', '관악구', '광진구', '구로구', '금천구',
        '노원구', '도봉구', '동대문구', '동작구', '마포구', '서대문구', '서초구', '성동구',
        '성북구', '송파구', '양천구', '영등포구', '용산구', '은평구', '종로구', '중구', '중랑구'
    ]
    
    gyeonggi_cities = [
        '가평군', '고양시', '과천시', '광명시', '광주시', '구리시', '군포시', '김포시',
        '남양주시', '동두천시', '부천시', '성남시', '수원시', '시흥시', '안산시', '안성시',
        '안양시', '양주시', '양평군', '여주시', '연천군', '오산시', '용인시', '의왕시',
        '의정부시', '이천시', '파주시', '평택시', '포천시', '하남시', '화성시'
    ]

    # 도시 리스트를 동적으로 업데이트할 함수
    def update_city_options(*args):
        selected_province = province_var.get()
        
        if selected_province == "서울특별시":
            city_combobox['values'] = seoul_districts
        elif selected_province == "경기도":
            city_combobox['values'] = gyeonggi_cities
        else:
            city_combobox['values'] = ['-']
        city_combobox.set('')

    # 라벨 및 입력 필드들
    tk.Label(win, text="Name").grid(row=0, column=0, padx=5, pady=5)
    tk.Label(win, text="SSN").grid(row=1, column=0, padx=5, pady=5)
    tk.Label(win, text="Blood Type").grid(row=2, column=0, padx=5, pady=5)
    tk.Label(win, text="Rh Factor").grid(row=3, column=0, padx=5, pady=5)
    tk.Label(win, text="Last Test Date (YYYY-MM-DD)").grid(row=4, column=0, padx=5, pady=5)
    tk.Label(win, text="Email").grid(row=5, column=0, padx=5, pady=5)
    tk.Label(win, text="Province").grid(row=6, column=0, padx=5, pady=5)
    tk.Label(win, text="City").grid(row=7, column=0, padx=5, pady=5)

    # 입력 필드들
    name_entry = tk.Entry(win)
    ssn_entry = tk.Entry(win)
    blood_entry = ttk.Combobox(win, values=["A", "B", "O", "AB"], state="readonly")
    rh_entry = ttk.Combobox(win, values=['+', '-'], state="readonly")
    last_test_date_entry = tk.Entry(win)
    email_entry = tk.Entry(win)
    
    province_var = tk.StringVar()
    province_combobox = ttk.Combobox(win, values=province_option, state="readonly", textvariable=province_var)
    province_combobox.bind("<<ComboboxSelected>>", update_city_options)
    city_combobox = ttk.Combobox(win, state="readonly")
    
    name_entry.grid(row=0, column=1, padx=5, pady=5)
    ssn_entry.grid(row=1, column=1, padx=5, pady=5)
    blood_entry.grid(row=2, column=1, padx=3, pady=5)
    rh_entry.grid(row=3, column=1, padx=3, pady=5)
    last_test_date_entry.grid(row=4, column=1, padx=5, pady=5)
    email_entry.grid(row=5, column=1, padx=5, pady=5)
    province_combobox.grid(row=6, column=1, padx=5, pady=5)
    city_combobox.grid(row=7, column=1, padx=5, pady=5)

    city_info_label = tk.Label(win, text="* 서울특별시와 경기도를 제외한 지역은  - 를 선택하면 됩니다.", 
                               font=("Arial", 8, "italic"), fg="gray")
    city_info_label.grid(row=8, column=1, padx=5, pady=5, sticky="w")
    
    tk.Label(win, text="Check Result ID").grid(row=9, column=0, padx=5, pady=5)
    checkresult_id_entry = tk.Entry(win)
    checkresult_id_entry.grid(row=9, column=1, padx=5, pady=5)

    def display_patients(donor_id, patients):
        # 환자 정보를 표시하는 테이블 생성
        patient_frame = tk.Frame(win, borderwidth=2, relief="groove")
        patient_frame.grid(row=10, column=0, columnspan=2, padx=10, pady=10)

        label = tk.Label(patient_frame, text="Matched Patients", font=("Arial", 12, "bold"))
        label.pack(pady=5)

        columns = ("ID", "Name", "Blood Type", "Rh Factor", "Due Date", "Email")
        tree = ttk.Treeview(patient_frame, columns=columns, show="headings", height=10)

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, anchor="center")

        for patient in patients:
            tree.insert("", "end", values=patient)

        tree.pack(side="top", fill="x")

    def on_submit():
        name = name_entry.get()
        ssn = ssn_entry.get()
        blood = blood_entry.get()
        rh = rh_entry.get()
        last_test_date = last_test_date_entry.get()
        email = email_entry.get()
        province = province_combobox.get()  # Province 선택
        city = city_combobox.get()          # City 선택
        checkresult = checkresult_id_entry.get()

        if not name or not ssn or not blood or not rh or not last_test_date or not email:
            messagebox.showerror("Input Error", "All fields are required.")
            return

        # Address는 province와 city를 결합하여 생성
        address = f"{province} {city}"

        # checkresult 합격인지 검증
        try:
            cursor.execute("SELECT Is_eligible FROM PRECHECKRESULT WHERE InputlistID = %s", (checkresult,))
            result = cursor.fetchone()

            if not result:
                messagebox.showerror("Error", "No such ID exists.")
                return

            is_eligible = result[0]  # Is_eligible 열 값 가져오기

            if is_eligible == 1:
                messagebox.showinfo("Success", "Eligibility check passed. Insertion successful.")
            else:
                messagebox.showerror("Error", "Eligibility check failed. Donation is not allowed.")
                return

        except Exception as e:
            messagebox.showerror("Database Error", f"An error occurred: {str(e)}")
            return

        try:
            datetime.strptime(last_test_date, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Date Error", "Date must be in YYYY-MM-DD format.")
            return

        # 헌혈자 삽입 및 매칭된 환자 검색
        d_id, patients = insert_donor_and_get_patients(name, ssn, blood, rh, last_test_date, email, address, checkresult)
        tk.Label(win, text=f"Donor ID: {d_id}", font=("Arial", 10)).grid(row=10, column=0, columnspan=2, pady=10)
        display_patients(d_id, patients)

    submit_btn = tk.Button(win, text="Insert & Get Patients", command=on_submit)
    submit_btn.grid(row=11, column=0, columnspan=2, pady=10)

# (3)번 메뉴: 매칭 데이터 조회 및 입력
def show_match_data():
    win = tk.Toplevel(root)
    win.title("Match Data")

    def refresh_data():
        # 기존 데이터 삭제
        for row in tree.get_children():
            tree.delete(row)

        # 데이터베이스에서 Matches 테이블과 관련 이름 데이터 가져오기
        query = """
        SELECT m.match_id, 
               m.patient_id, 
               p.name AS patient_name, 
               m.donor_id, 
               d.name AS donor_name, 
               m.is_success, 
               h.Name AS hospital_name
        FROM Matches m
        JOIN Patients p ON m.patient_id = p.patient_id
        JOIN Donors d ON m.donor_id = d.donor_id
        LEFT JOIN Hospital h ON d.HospitalID = h.HospitalID
        """
        cursor.execute(query)
        matches = cursor.fetchall()

        # 데이터 변환 및 테이블에 삽입
        for match in matches:
            match_status = "Success" if match[5] == 1 else "Fail"  # 1이면 Success, 0이면 Fail로 변환
            hospital_name = match[6] if match[6] else "N/A"  # 병원이 없으면 N/A 표시
            tree.insert("", "end", values=(match[0], match[1], match[2], match[3], match[4], match_status, hospital_name))

    def insert_match():
        patient_id = patient_id_entry.get()
        donor_id = donor_id_entry.get()
        match_status = match_status_combobox.get()

        if not patient_id or not donor_id or not match_status:
            messagebox.showerror("Input Error", "All fields are required.")
            return

        # Match Status를 BOOLEAN으로 변환
        is_success = 1 if match_status == "Success" else 0

        try:
            # Matches 테이블에 데이터 삽입
            cursor.execute(
                "INSERT INTO Matches (patient_id, donor_id, is_success) VALUES (%s, %s, %s)",
                (patient_id, donor_id, is_success)
            )
            conn.commit()
            messagebox.showinfo("Insert Success", "Match data inserted successfully.")

            # 데이터 삽입 후 Refresh
            refresh_data()
        except Exception as e:
            messagebox.showerror("Database Error", str(e))

    frame = tk.Frame(win, borderwidth=2, relief="groove")
    frame.pack(side="top", fill="x", pady=5)

    label = tk.Label(frame, text="Match Data", font=("Arial", 12, "bold"))
    label.pack(pady=5)


    columns = ("Match ID", "Patient ID", "Patient Name", "Donor ID", "Donor Name", "Match Status", "Recommended Hospital")
    tree = ttk.Treeview(frame, columns=columns, show="headings", height=10)

    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, anchor="center")

    tree.pack(side="top", fill="x")

    # 데이터 삽입 섹션
    insert_frame = tk.Frame(win, borderwidth=2, relief="groove")
    insert_frame.pack(side="top", fill="x", pady=10)

    tk.Label(insert_frame, text="Patient ID").grid(row=0, column=0, padx=5, pady=5)
    tk.Label(insert_frame, text="Donor ID").grid(row=1, column=0, padx=5, pady=5)
    tk.Label(insert_frame, text="Match Status").grid(row=2, column=0, padx=5, pady=5)

    patient_id_entry = tk.Entry(insert_frame)
    donor_id_entry = tk.Entry(insert_frame)
    match_status_combobox = ttk.Combobox(insert_frame, values=["Success", "Fail"], state="readonly")

    patient_id_entry.grid(row=0, column=1, padx=5, pady=5)
    donor_id_entry.grid(row=1, column=1, padx=5, pady=5)
    match_status_combobox.grid(row=2, column=1, padx=5, pady=5)

    insert_btn = tk.Button(insert_frame, text="Insert Match Data", command=insert_match)
    insert_btn.grid(row=3, column=0, columnspan=2, pady=10)

    refresh_btn = tk.Button(win, text="Refresh Data", command=refresh_data)
    refresh_btn.pack(side="bottom", pady=10)

    # 초기 데이터 로드
    refresh_data()

# 메인 윈도우 설정
root = tk.Tk()
root.title("Leukocyte Donation Management System")

header_frame = tk.Frame(root, borderwidth=2, relief="ridge", bg="#f0f8ff")
header_frame.pack(fill="x", pady=10)

title_label = tk.Label(header_frame, text="Leukocyte Donation Management System", 
                       font=("Helvetica", 16, "bold"), bg="#f0f8ff", fg="#004080")
title_label.pack(pady=5)

description_label = tk.Label(header_frame, text="Manage patient and donor data with ease. Match them efficiently and send notifications.",
                             font=("Helvetica", 10), bg="#f0f8ff", fg="#006699")
description_label.pack(pady=5)

menu_frame = tk.Frame(root, borderwidth=2, relief="groove", bg="#e6f2ff")
menu_frame.pack(pady=20, padx=20)

btn1 = tk.Button(menu_frame, text="(1) Insert Patient & Get Matched Donors", command=show_insert_patient_window,
                 font=("Arial", 12), width=30)
btn1.grid(row=0, column=0, padx=10, pady=10)

btn2 = tk.Button(menu_frame, text="(2) Insert Donor & Get Matched Patients", command=show_insert_donor_window,
                 font=("Arial", 12), width=30)
btn2.grid(row=1, column=0, padx=10, pady=10)

btn3 = tk.Button(menu_frame, text="(3) View & Manage Match Data", command=show_match_data,
                 font=("Arial", 12), width=30)
btn3.grid(row=2, column=0, padx=10, pady=10)

footer_label = tk.Label(root, text="Developed by Yongwoo Park, Soyun Kim, Junho Yeo, Jaesuh Kim | 2024", font=("Helvetica", 8), bg="#e6f2ff", fg="#006699")
footer_label.pack(side="bottom", pady=5)

root.mainloop()

# 종료 시 DB 커넥션 종료
cursor.close()
conn.close()