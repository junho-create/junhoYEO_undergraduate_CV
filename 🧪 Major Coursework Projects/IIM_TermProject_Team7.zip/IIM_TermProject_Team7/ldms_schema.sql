USE ldms;

-- PRECHECKRESULT 테이블 생성
CREATE TABLE PRECHECKRESULT (
  InputlistID INT AUTO_INCREMENT,
  AgeCheck INT NOT NULL,
  WeightCheck INT NOT NULL,
  DangerousTravelCheck ENUM('Pass', 'Fail') NOT NULL,
  HemoglobinLevelCheck ENUM('Pass', 'Fail') NOT NULL,
  VirusOrDiseaseCheckResult ENUM('Pass', 'Fail') NOT NULL,
  WhiteBloodCheck ENUM('Pass', 'Fail') NOT NULL,
  Is_eligible BOOLEAN NULL,
  PRIMARY KEY (InputlistID)
);

-- trigger: 검사결과 확인하고 pass 일 경우 is_eligible에 1, 아닐경우 0 
DELIMITER //

CREATE TRIGGER check_eligibility
BEFORE INSERT ON PRECHECKRESULT
FOR EACH ROW
BEGIN
    IF NEW.AgeCheck >= 18 AND NEW.AgeCheck < 60 AND
       NEW.WeightCheck >= 50 AND NEW.WeightCheck < 100 AND
       NEW.DangerousTravelCheck = 'Pass' AND
       NEW.HemoglobinLevelCheck = 'Pass' AND
       NEW.VirusOrDiseaseCheckResult = 'Pass' AND
       NEW.WhiteBloodCheck = 'Pass' THEN
        SET NEW.Is_eligible = TRUE;
    ELSE
        SET NEW.Is_eligible = FALSE;
    END IF;
END;

//
DELIMITER ;

-- sample data insertion: 랜덤으로 check pass/fail 되도록 만들어놓음.
INSERT INTO PRECHECKRESULT (AgeCheck, WeightCheck, DangerousTravelCheck, HemoglobinLevelCheck, VirusOrDiseaseCheckResult, WhiteBloodCheck) 
VALUES 
(51, 70, 'Pass', 'Pass', 'Pass', 'Pass'),
(37, 65, 'Pass', 'Pass', 'Pass', 'Pass'),
(30, 55, 'Pass', 'Pass', 'Pass', 'Pass'),
(49, 75, 'Pass', 'Pass', 'Pass', 'Pass'),
(23, 68, 'Pass', 'Pass', 'Pass', 'Pass'),
(35, 80, 'Pass', 'Pass', 'Pass', 'Pass'),
(53, 60, 'Pass', 'Pass', 'Pass', 'Pass'),
(24, 70, 'Pass', 'Pass', 'Pass', 'Pass'),
(48, 65, 'Pass', 'Pass', 'Pass', 'Pass'),
(33, 72, 'Pass', 'Pass', 'Pass', 'Pass'),
(40, 58, 'Pass', 'Pass', 'Pass', 'Pass'),
(22, 77, 'Pass', 'Pass', 'Pass', 'Pass'),
(46, 66, 'Pass', 'Pass', 'Pass', 'Pass'),
(39, 55, 'Pass', 'Pass', 'Pass', 'Pass'),
(52, 60, 'Pass', 'Pass', 'Pass', 'Pass'),
(37, 78, 'Pass', 'Pass', 'Pass', 'Pass'),
(37, 68, 'Pass', 'Pass', 'Pass', 'Pass'),
(31, 59, 'Pass', 'Pass', 'Pass', 'Pass'),
(19, 62, 'Pass', 'Pass', 'Pass', 'Pass'),
(54, 70, 'Pass', 'Pass', 'Pass', 'Pass'),
(45, 65, 'Pass', 'Pass', 'Pass', 'Pass'),
(26, 80, 'Pass', 'Pass', 'Pass', 'Pass'),
(34, 67, 'Pass', 'Pass', 'Pass', 'Pass'),
(42, 55, 'Pass', 'Pass', 'Pass', 'Pass'),
(31, 72, 'Pass', 'Pass', 'Pass', 'Pass'),
(19, 75, 'Pass', 'Pass', 'Pass', 'Pass'),
(36, 68, 'Pass', 'Pass', 'Pass', 'Pass'),
(30, 60, 'Pass', 'Pass', 'Pass', 'Pass'),
(51, 70, 'Pass', 'Pass', 'Pass', 'Pass'),
(42, 66, 'Pass', 'Pass', 'Pass', 'Pass'),
(40, 48, 'Fail', 'Pass', 'Fail', 'Fail'),
(61, 45, 'Pass', 'Fail', 'Fail', 'Fail'),
(15, 40, 'Fail', 'Fail', 'Fail', 'Fail'),
(62, 105, 'Fail', 'Pass', 'Pass', 'Fail'),
(14, 38, 'Fail', 'Fail', 'Fail', 'Fail'),
(63, 110, 'Pass', 'Fail', 'Fail', 'Fail'),
(12, 30, 'Fail', 'Fail', 'Fail', 'Fail'),
(16, 45, 'Fail', 'Pass', 'Fail', 'Fail'),
(70, 120, 'Fail', 'Fail', 'Fail', 'Fail'),
(10, 25, 'Fail', 'Fail', 'Fail', 'Fail'),
(65, 115, 'Fail', 'Pass', 'Fail', 'Fail'),
(13, 35, 'Fail', 'Fail', 'Fail', 'Fail'),
(68, 108, 'Pass', 'Fail', 'Fail', 'Fail'),
(11, 28, 'Fail', 'Fail', 'Fail', 'Fail'),
(15, 45, 'Fail', 'Fail', 'Fail', 'Fail'),
(66, 112, 'Pass', 'Fail', 'Fail', 'Fail'),
(18, 49, 'Fail', 'Pass', 'Fail', 'Fail'),
(64, 100, 'Fail', 'Fail', 'Fail', 'Fail'),
(71, 120, 'Fail', 'Fail', 'Fail', 'Fail'),
(14, 35, 'Fail', 'Fail', 'Fail', 'Fail'),
(50, 80, 'Pass', 'Pass', 'Pass', 'Pass'),
(28, 65, 'Pass', 'Pass', 'Pass', 'Pass'),
(45, 70, 'Pass', 'Pass', 'Pass', 'Pass'),
(39, 75, 'Pass', 'Pass', 'Pass', 'Pass'),
(32, 60, 'Pass', 'Pass', 'Pass', 'Pass'),
(41, 68, 'Pass', 'Pass', 'Pass', 'Pass'),
(53, 85, 'Pass', 'Pass', 'Pass', 'Pass'),
(26, 70, 'Pass', 'Pass', 'Pass', 'Pass'),
(47, 72, 'Pass', 'Pass', 'Pass', 'Pass'),
(33, 65, 'Pass', 'Pass', 'Pass', 'Pass');


-- HOSPITAL 테이블 생성
CREATE TABLE HOSPITAL (
  HospitalID INT NOT NULL,
  Name VARCHAR(45) NOT NULL,
  EmailAddress VARCHAR(45) NULL,
  ContactNumber VARCHAR(45) NULL,
  Location VARCHAR(45) NOT NULL,
  PRIMARY KEY (HospitalID)
);


INSERT INTO HOSPITAL (HospitalID, Name, EmailAddress, ContactNumber, Location)
VALUES
(1, '가톨릭대학교 성빈센트병원', 'contact@cmcvincent.or.kr', '1577-8588', '경기'),
(2, '부산대학교병원', 'contact@pnuh.co.kr', '051-240-7000', '부산'),
(3, '서울대학교병원', 'info@snuh.org', '02-2072-2114', '서울'),
(4, '삼성서울병원', 'support@samsunghospital.com', '02-3410-2114', '서울'),
(5, '서울아산병원', 'admin@amc.seoul.kr', '1688-7575', '서울'),
(6, '전북대학교병원', 'info@jbnuh.co.kr', '063-250-1114', '전북'),
(7, '서울성모병원', 'contact@cmcseoul.or.kr', '1588-1511', '서울'),
(8, '건국대학교병원', 'info@kuh.ac.kr', '02-1588-1533', '서울'),
(9, '화순전남대학교병원', 'support@cnuhh.com', '061-379-7114', '전남'),
(10, '고려대학교 안암병원', 'contact@anam.kumc.or.kr', '02-1577-0083', '서울'),
(11, '국립암센터', 'info@ncc.re.kr', '031-920-0114', '경기');


-- Donors 테이블
CREATE TABLE Donors (
    donor_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    ssn VARCHAR(20) NOT NULL,
    blood_type VARCHAR(5) NOT NULL,
    rh_factor CHAR(1) NOT NULL, 
    last_test_date DATE,
    email VARCHAR(100),
    donor_address VARCHAR(100), -- address 추가
    InputlistID INT,  -- Foreign Key 추가
    HospitalID INT NULL,

    CONSTRAINT ssn_unique UNIQUE KEY (ssn),
    CONSTRAINT donor_bloodtypeCheck CHECK (blood_type IN ('A','B','AB','O')),
    CONSTRAINT donor_rhfactorCheck CHECK (rh_factor IN ('+','-')),
    CONSTRAINT fk_precheckresult_inputlistid FOREIGN KEY (InputlistID)
        REFERENCES PRECHECKRESULT(InputlistID)
        ON DELETE SET NULL
        ON UPDATE CASCADE,
    CONSTRAINT fk_hospital_hospitalid FOREIGN KEY (HospitalID)
        REFERENCES HOSPITAL(HospitalID)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);



-- 병원 할당 트리거(설명서에 없는 지역 넣으면 국립암센터로 일괄배정)
DELIMITER $$

CREATE TRIGGER set_hospital_id_on_donor_insert
BEFORE INSERT ON Donors
FOR EACH ROW
BEGIN
    DECLARE hospital_id INT;

    -- HospitalID 설정 로직
    IF NEW.donor_address IN ('서울특별시 강남구', '서울특별시 강서구', '서울특별시 영등포구', '서울특별시 용산구', '서울특별시 마포구', 
                              '서울특별시 동작구', '서울특별시 노원구', '서울특별시 성북구', '서울특별시 강동구', '서울특별시 동대문구', '서울특별시 양천구') THEN 
        SET hospital_id = 4;
    ELSEIF NEW.donor_address IN ('서울특별시 송파구') THEN
        SET hospital_id = 5;
    ELSEIF NEW.donor_address IN ('서울특별시 종로구', '서울특별시 중구', '서울특별시 은평구', '서울특별시 서대문구', '서울특별시 금천구', '서울특별시 구로구') THEN
        SET hospital_id = 3;
    ELSEIF NEW.donor_address IN ('서울특별시 관악구', '서울특별시 서초구') THEN
        SET hospital_id = 7;
    ELSEIF NEW.donor_address IN ('서울특별시 광진구', '서울특별시 성동구', '서울특별시 중랑구', '서울특별시 도봉구', '서울특별시 강북구') THEN
        SET hospital_id = 8;
    ELSEIF NEW.donor_address IN ('경기도 성남시', '경기도 용인시', '경기도 수원시', '경기도 고양시', '경기도 안양시', '경기도 의정부시', '경기도 안산시', 
                                  '경기도 파주시', '경기도 평택시', '경기도 화성시', '경기도 시흥시', '경기도 군포시', '경기도 광명시', '경기도 하남시', 
                                  '경기도 양주시', '경기도 동두천시', '경기도 연천군', '경기도 김포시') THEN
        SET hospital_id = 1;
    ELSEIF NEW.donor_address IN ('부산광역시 -') THEN
        SET hospital_id = 2;
    ELSEIF NEW.donor_address IN ('전라북도 -') THEN 
        SET hospital_id = 6;
    ELSEIF NEW.donor_address IN ('전라남도 -') THEN 
        SET hospital_id = 9;
    ELSEIF NEW.donor_address IN ('경상남도 -', '경상북도 -', '대구광역시 -', '울산광역시 -', '제주특별자치도 -') THEN
        SET hospital_id = 2;
    ELSEIF NEW.donor_address IN ('강원도 -', '충청남도 -', '충청북도 -', '세종특별자치시 -') THEN
        SET hospital_id = 1;
    ELSE
        SET hospital_id = 11;
    END IF;
    
    SET NEW.HospitalID = hospital_id;
END;
$$


DELIMITER ;


INSERT INTO Donors (name, ssn, blood_type, rh_factor, last_test_date, email, donor_address, InputlistID)
VALUES
('John Doe', '730427-3843744', 'A', '+', '2024-12-01', 'john.doe@example.com', '서울특별시 강남구', 1),
('Jane Smith', '870124-1221831', 'B', '-', '2024-11-30', 'jane.smith@example.com', '서울특별시 송파구', 2),
('Alice Johnson', '941103-4072049', 'AB', '+', '2024-11-28', 'alice.johnson@example.com', '서울특별시 서초구', 3),
('Bob Brown', '751211-2930152', 'O', '-', '2024-11-20', 'bob.brown@example.com', '부산광역시', 4),
('Charlie Davis', '010126-1810338', 'A', '+', '2024-11-15', 'charlie.davis@example.com', '경기도 성남시', 5),
('Diana Lee', '891110-4849292', 'B', '+', '2024-12-05', 'diana.lee@example.com', '경기도 용인시', 6),
('Eve Wilson', '710316-3043300', 'AB', '-', '2024-11-25', 'eve.wilson@example.com', '경기도 수원시', 7),
('Frank Miller', '000702-2193967', 'O', '+', '2024-11-10', 'frank.miller@example.com', '경기도 고양시', 8),
('Grace Moore', '761117-2708218', 'A', '-', '2024-12-02', 'grace.moore@example.com', '서울특별시 강남구', 9),
('Hank Taylor', '910625-4697370', 'B', '-', '2024-11-22', 'hank.taylor@example.com', '서울특별시 송파구', 10),
('Ivy Anderson', '841110-2847730', 'O', '+', '2024-12-03', 'ivy.anderson@example.com', '서울특별시 서초구', 11),
('Jack Thomas', '021017-2996248', 'AB', '-', '2024-11-27', 'jack.thomas@example.com', '경기도 안양시', 12),
('Karen White', '780811-2394475', 'A', '+', '2024-11-18', 'karen.white@example.com', '경기도 의정부시', 13),
('Leo King', '850104-1410735', 'B', '+', '2024-12-06', 'leo.king@example.com', '경기도 안산시', 14),
('Mia Clark', '720306-1858369', 'AB', '+', '2024-11-24', 'mia.clark@example.com', '경기도 부천시', 15),
('Nate Allen', '870312-2110019', 'O', '-', '2024-11-12', 'nate.allen@example.com', '경기도 파주시', 16),
('Olivia Wright', '870526-1205282', 'A', '-', '2024-12-04', 'olivia.wright@example.com', '서울특별시 강남구', 17),
('Samuel Green', '930819-1860461', 'B', '+', '2024-12-05', 'samuel.green@example.com', '서울특별시 서초구', 18),
('Tom Harris', '050902-2129761', 'O', '-', '2024-12-01', 'tom.harris@example.com', '서울특별시 송파구', 19),
('Ursula King', '700624-4293498', 'AB', '+', '2024-11-29', 'ursula.king@example.com', '서울특별시 강남구', 20),
('Victor Hall', '790508-1115746', 'A', '-', '2024-11-21', 'victor.hall@example.com', '서울특별시 중구', 21),
('Wendy Scott', '980219-1113122', 'B', '+', '2024-12-07', 'wendy.scott@example.com', '서울특별시 용산구', 22),
('Xander Lee', '900919-3956406', 'O', '+', '2024-12-03', 'xander.lee@example.com', '서울특별시 동대문구', 23),
('Yvonne Clark', '820323-2302979', 'AB', '-', '2024-12-06', 'yvonne.clark@example.com', '서울특별시 강동구', 24),
('Zachary Adams', '930909-2557652', 'A', '+', '2024-11-30', 'zachary.adams@example.com', '서울특별시 성북구', 25),
('Abigail Cooper', '050205-1057475', 'B', '-', '2024-11-19', 'abigail.cooper@example.com', '전라북도', 26),
('Benjamin Moore', '880717-1106023', 'O', '+', '2024-11-25', 'benjamin.moore@example.com', '경기도 시흥시', 27),
('Catherine Harris', '721104-3759966', 'AB', '-', '2024-12-02', 'catherine.harris@example.com', '경기도 군포시', 28),
('David Allen', '871115-4482369', 'A', '+', '2024-11-15', 'david.allen@example.com', '경기도 광명시', 29),
('Ella Mitchell', '830601-1877488', 'B', '+', '2024-12-03', 'ella.mitchell@example.com', '경상남도', 30),
('Finn Baker', '050616-4687606', 'O', '-', '2024-11-28', 'finn.baker@example.com', '강원도', 31),
('Grace Harris', '820518-3721917', 'AB', '+', '2024-12-04', 'grace.harris@example.com', '충청남도', 32),
('Henry Adams', '840304-2838750', 'A', '-', '2024-11-22', 'henry.adams@example.com', '경상북도', 33),
('Ivy Jordan', '951001-3042732', 'B', '+', '2024-12-07', 'ivy.jordan@example.com', '제주특별자치도', 34),
('Jake Nelson', '730316-4418259', 'O', '+', '2024-11-16', 'jake.nelson@example.com', '대구광역시', 35),
('Lily Moore', '820915-1467066', 'AB', '-', '2024-11-29', 'lily.moore@example.com', '경기도 성남시', 36),
('Mason Lee', '730203-3890300', 'A', '+', '2024-12-05', 'mason.lee@example.com', '서울특별시 강남구', 37),
('Nina Johnson', '060828-4716555', 'B', '-', '2024-11-18', 'nina.johnson@example.com', '서울특별시 서초구', 38),
('Oscar Kim', '030802-3583909', 'O', '+', '2024-12-06', 'oscar.kim@example.com', '서울특별시 송파구', 39),
('Penny Scott', '901206-3371132', 'AB', '-', '2024-11-10', 'penny.scott@example.com', '서울특별시 용산구', 40),
('Quinn Turner', '850826-4368795', 'A', '-', '2024-11-24', 'quinn.turner@example.com', '서울특별시 강남구', 41),
('Ryan Evans', '701102-1482116', 'B', '+', '2024-12-02', 'ryan.evans@example.com', '서울특별시 강서구', 42),
('Sophia Baker', '850907-3431574', 'O', '-', '2024-11-28', 'sophia.baker@example.com', '서울특별시 동작구', 43),
('Tommy Clark', '860724-2148930', 'AB', '+', '2024-12-01', 'tommy.clark@example.com', '경기도 화성시', 44),
('Uma Lewis', '940605-2284410', 'A', '-', '2024-11-19', 'uma.lewis@example.com', '서울특별시 영등포구', 45),
('Vera Miller', '860707-1035200', 'B', '+', '2024-11-15', 'vera.miller@example.com', '서울특별시 용산구', 46),
('Walter King', '800908-3676595', 'O', '+', '2024-11-25', 'walter.king@example.com', '서울특별시 마포구', 47),
('Xena Clark', '760924-2978143', 'AB', '-', '2024-12-07', 'xena.clark@example.com', '경기도 하남시', 48),
('Yara Green', '820626-3942119', 'A', '+', '2024-12-02', 'yara.green@example.com', '서울특별시 동대문구', 49),
('Zane Moore', '040225-4770018', 'B', '-', '2024-11-18', 'zane.moore@example.com', '서울특별시 강동구', 50);



-- Patients 테이블
CREATE TABLE Patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    blood_type VARCHAR(5) NOT NULL,
    rh_factor CHAR(1) NOT NULL,
    due_date DATE,
    email VARCHAR(100),
    admitted_date DATE,
    CONSTRAINT patient_bloodtypeCheck CHECK (blood_type IN ('A','B','AB','O')),
    CONSTRAINT patient_rhfactorCheck CHECK (rh_factor IN ('+','-'))
);


-- Matches 테이블
CREATE TABLE Matches (
    match_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    donor_id INT NOT NULL,
    is_success BOOLEAN,
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id),
    FOREIGN KEY (donor_id) REFERENCES Donors(donor_id)
);


select * from patients


-- 호환성 체크 함수 (기본 ABO 동일 여부 + Rh 일치여부 반환)
DELIMITER $$
CREATE FUNCTION check_abo_compatibility(p_blood VARCHAR(5), d_blood VARCHAR(5))
RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    RETURN p_blood = d_blood;
END;

CREATE FUNCTION check_rh_compatibility(p_rh CHAR(1), d_rh CHAR(1))
RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    RETURN p_rh = d_rh;
END;

$$ DELIMITER ;

-- Trigger: 같은 사람(동일 ssn) Donors Insert 시 last_test_date만 갱신

DELIMITER $$
CREATE TRIGGER DonorsInsertTrigger
BEFORE INSERT ON Donors
FOR EACH ROW
BEGIN
    DECLARE existing_donor_id INT;

    -- 동일한 SSN을 가진 데이터가 존재하는지 확인
    SELECT donor_id INTO existing_donor_id
    FROM Donors
    WHERE ssn = NEW.ssn;

    IF existing_donor_id IS NOT NULL THEN
        -- 새로운 INSERT를 차단
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Duplicate SSN detected. Please update last_test_date manually.';
    END IF;
END;
$$ DELIMITER ;


DELIMITER $$
CREATE PROCEDURE get_matched_donors_for_patient(IN p_id INT)
BEGIN
    SELECT d.donor_id, d.name, d.blood_type, d.rh_factor, d.last_test_date, d.email,
           CASE
               WHEN check_abo_compatibility(p.blood_type, d.blood_type)
                    AND check_rh_compatibility(p.rh_factor, d.rh_factor) THEN 1
               WHEN check_abo_compatibility(p.blood_type, d.blood_type)
                    AND NOT check_rh_compatibility(p.rh_factor, d.rh_factor) THEN 2
               WHEN d.blood_type = 'O' AND check_rh_compatibility(p.rh_factor, d.rh_factor) THEN 3
               WHEN d.blood_type = 'O' AND NOT check_rh_compatibility(p.rh_factor, d.rh_factor) THEN 4
               ELSE 5
           END AS priority
    FROM Patients p
    JOIN Donors d
    ON check_abo_compatibility(p.blood_type, d.blood_type) OR d.blood_type = 'O'
    WHERE p.patient_id = p_id
    ORDER BY priority, d.last_test_date DESC;
END
$$
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE get_matched_patients_for_donor(IN d_id INT)
BEGIN
    SELECT p.patient_id, 
           p.name, 
           p.blood_type, 
           p.rh_factor, 
           p.due_date, 
           p.email
    FROM Donors d
    JOIN Patients p 
    ON check_abo_compatibility(p.blood_type, d.blood_type)
       AND check_rh_compatibility(p.rh_factor, d.rh_factor)
    WHERE d.donor_id = d_id
    ORDER BY p.due_date ASC;
END
$$ DELIMITER ;