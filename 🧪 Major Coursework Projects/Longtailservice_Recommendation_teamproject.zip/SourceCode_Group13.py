import pandas as pd
from lightfm import LightFM
from lightfm.evaluation import precision_at_k
from lightfm.evaluation import recall_at_k
from scipy.sparse import coo_matrix
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

# Load Dataset
try:
    data = pd.read_csv(r'C:\Users\rmsid\Downloads\archive\ratings_small.csv')
    print("Dataset loaded.")
except Exception as e:
    print(f"Error: {e}")


# Process Dataset
user_ids = data['user_id'].unique()
movie_ids = data['movie_id'].unique()

user_to_index = {user_id: index for index, user_id in enumerate(user_ids)}
movie_to_index = {movie_id: index for index, movie_id in enumerate(movie_ids)}

rows = data['user_id'].map(user_to_index)
cols = data['movie_id'].map(movie_to_index)
ratings = data['rating']

interaction_matrix = coo_matrix((ratings, (rows, cols)), shape=(len(user_to_index), len(movie_to_index)))
print(interaction_matrix)


# Sparsity Calculation
def calculate_sparsity(interaction_matrix):
    total_possible_interactions = interaction_matrix.shape[0] * interaction_matrix.shape[1]
    actual_interactions = interaction_matrix.nnz
    sparsity = 1 - (actual_interactions / total_possible_interactions)
    return sparsity

sparsity = calculate_sparsity(interaction_matrix)
print(f"Sparsity: {sparsity:.4f}")


# LightFM Model
model = LightFM(loss='logistic')
model.fit(interaction_matrix, epochs=30, num_threads=4, verbose=True)

lightfm_precision = precision_at_k(model, interaction_matrix, k=5).mean()
lightfm_recall = recall_at_k(model, interaction_matrix, k=5).mean()


# Recommendation from LightFM
def recommend_movies_lightfm(model, user_id, user_to_index, n_recommendations=5):
    if user_id not in user_to_index:
        print(f"User ID {user_id} is not in the dataset.")
        return []

    user_index = user_to_index[user_id]
    scores = model.predict(user_index, np.arange(interaction_matrix.shape[1]))
    top_items = movie_ids[np.argsort(-scores)]  # descending order
    return top_items[:n_recommendations]

lightfm_recommendations = recommend_movies_lightfm(model, user_id=1, user_to_index=user_to_index)


# Recommendation from User-based CF
user_movie_matrix = interaction_matrix.toarray()
user_similarity = cosine_similarity(user_movie_matrix)

def recommend_user_based(user_id, user_movie_matrix, user_similarity, n_recommendations=5):
    user_idx = user_to_index[user_id]
    similar_users = user_similarity[user_idx]
    most_similar_user = similar_users.argsort()[-2]
    recommendations = np.argsort(user_movie_matrix[most_similar_user])[::-1][:n_recommendations]
    return movie_ids[recommendations]

user_recommendations = recommend_user_based(user_id=1, user_movie_matrix=user_movie_matrix, user_similarity=user_similarity)


# Precision@K and Recall@K Functions
def precision_at_k_simple(recommended, relevant, k=5):
    recommended_at_k = set(recommended[:k])
    relevant_set = set(relevant)
    precision = len(recommended_at_k & relevant_set) / k
    return precision

def recall_at_k_simple(recommended, relevant, k=5):
    recommended_at_k = set(recommended[:k])
    relevant_set = set(relevant)
    if len(relevant_set) == 0:
        return 0  # Avoid division by zero
    recall = len(recommended_at_k & relevant_set) / len(relevant_set)
    return recall

user_id = 1
relevant_movies = data[data['user_id'] == user_id]['movie_id'].tolist()


# User-based CF Precision and Recall
user_precision = precision_at_k_simple(user_recommendations, relevant_movies)
user_recall = recall_at_k_simple(user_recommendations, relevant_movies)

print("Precision of LightFM: %.2f" % lightfm_precision)
print(f"Precision of User-based CF: {user_precision:.2f}")
print("Recall of LightFM: %.2f" % lightfm_recall)
print(f"Recall of User-based CF: {user_recall:.2f}")


# Print Recommendations
print("LightFM Recommendations for user {}: {}".format(user_id, lightfm_recommendations))
print("User-based CF Recommendations for user {}: {}".format(user_id, user_recommendations))